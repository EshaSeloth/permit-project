<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules

- Document bodies live only in `src/server-data/documents.json` and are imported only from `src/lib/rag/rag.server.ts`; client code gets users/questions from `src/lib/rag/dataset.ts`, so restricted text never ships to the browser. An answer may return full text only for documents in that user's permitted retrieved results.
- All permission decisions go through `canAccess` in `src/lib/rag/access.ts`, applied before retrieval ranking and again on the final AI context; superseded documents are excluded from retrieval.
- `src/test/rag-access.test.ts` must keep zero permission violations and zero forbidden hits across every question × user.
- Detail popups use the shared `CenteredModal` (native `<dialog>` with inline centering) because the design system's base styles override utility margins on `<dialog>`.
- Retrieval (`src/lib/rag/retrieve.ts`) stays pure and synchronous: it takes optional meaning-based scores (embeddings computed in `embeddings.server.ts`, falling back to keyword-only when unavailable) so tests and permission checks need no network. It pulls top-15 BM25 and top-15 semantic candidates from permitted docs (restricted to named customers + shared docs), searches once per customer for comparisons with a small per-customer quota, adds a follow-up hop from the top customer doc to related shared docs, then reranks to at most 8; customer names are dropped from keyword scoring so they do not drown out specific terms.
